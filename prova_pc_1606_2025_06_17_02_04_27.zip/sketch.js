// Variáveis Globais do Jogo
let campo = {}; // Objeto para o Campo
let cidade = {}; // Objeto para a Cidade

let tempo = 0; // Tempo de jogo em segundos
let jogoIniciado = false; // Flag para indicar se o jogo está em andamento
let ultimaAtualizacao = 0; // Timestamp da última atualização lógica
let intervalo = 1000; // Intervalo de atualização lógica (1 segundo)

let faseAtual = 1; // Fase atual do jogo
let tamanhoParaProximaFase = 150; // Tamanho combinado necessário para avançar de fase

let pontos = 0; // Pontuação do jogador

// Variáveis para os botões da interface
let botaoFacil, botaoMedio, botaoDificil;
let botaoInstrucoes, botaoVoltar, botaoConquistas; // Adicionado botaoConquistas

// Controle de tela atual do jogo
let telaAtual = "menu"; // Pode ser "menu", "jogo", "instrucoes", "fim", "historia", "faseCompleta", "vitoria", "tutorial", "conquistas"

// Variáveis para animação de altura de campo e cidade
let alturaCampoAnimada = 50;
let alturaCidadeAnimada = 50;

let eventoTimer = 0; // Timer para exibição de eventos temporários
let textoEvento = ""; // Texto do evento temporário a ser exibido

let limiteEstabilidade = 5; // Limite de estabilidade antes de um colapso (será ajustado pela dificuldade)

// Variáveis para controle da história
let janelaHistoria = 0; // Índice da linha de texto da história a ser exibida
let dificuldadeEscolhida = "facil"; // Dificuldade selecionada pelo usuário
let podePressionarEspaco = true; // Flag para controlar a progressão da história com a tecla ESPAÇO

// Variável para o oscilador de som (feedback de transferência)
let transferSound;

// Variáveis para os novos efeitos visuais
let transferParticles = []; // Array para as partículas de transferência
let campoCresceuRecently = 0; // Controla a intensidade da aura de crescimento do campo (0-255)
let cidadeCresceuRecently = 0; // Controla a intensidade da aura de crescimento da cidade (0-255)
let prodIncreaseIndicators = []; // Array para os indicadores de aumento de produção

// Variáveis para controle da tela de "Fase Concluída"
let faseConcluidaTimer = 0;
let faseConcluidaNumero = 0;
let faseConcluidaPontosGanhos = 0;

// --- VARIÁVEIS PARA EVENTOS ALEATÓRIOS ---
let proximoEventoTempo = 60; // Tempo em segundos para o próximo sorteio de evento
let eventoAtivo = null; // Armazena o evento ativo (null se nenhum)
let eventoFimTempo = 0; // Tempo em que o evento ativo termina
let chanceEvento = 0.3; // 30% de chance de um evento ocorrer a cada proximoEventoTempo

// --- VARIÁVEIS PARA CONDIÇÕES DE VITÓRIA/DERROTA ---
let tempoEquilibrioPerfeito = 0; // Contador de tempo para a condição de vitória de equilíbrio perfeito
let campoColapsadoDesde = 0; // Tempo em que o campo colapsou
let cidadeColapsadoDesde = 0; // Tempo em que a cidade colapsou
const TEMPO_PARA_DERROTA_COLAPSO = 30; // 30 segundos para derrota por dívida de estabilidade

// --- VARIÁVEIS PARA TUTORIAL E DICAS ---
let tutorialAtivo = false;
let tutorialStep = 0;
let tutorialStepsData = [
    {
        texto: "Bem-vindo(a) a Cidade & Campo! Seu objetivo é manter o equilíbrio entre as duas regiões, trocando recursos para que ambas cresçam.",
        foco: "geral"
    },
    {
        texto: "Aqui está o Campo! Ele produz Comida, Água e Energia. Para crescer, precisa de Bens e mais Comida, Água e Energia. Seus recursos estão aqui.",
        foco: "campoInfo"
    },
    {
        texto: "E aqui a Cidade! Ela produz Bens e Energia. Para crescer, precisa de Comida, Água e mais Bens e Energia. Seus recursos estão aqui.",
        foco: "cidadeInfo"
    },
    {
        texto: "A cada segundo, Campo e Cidade consomem 1 unidade de cada recurso. Se não houver recursos suficientes, a estabilidade diminui.",
        foco: "consumo"
    },
    {
        texto: "Você transfere recursos usando as teclas: 'C' (Comida: Campo → Cidade), 'B' (Bens: Cidade → Campo), 'A' (Água: Campo → Cidade), 'E' (Energia: Cidade → Campo).",
        foco: "controles"
    },
    {
        texto: "Se a estabilidade de uma região chegar ao limite, ela entra em colapso. Isso diminui a produção e pode levar à derrota. Transfira recursos para recuperá-la!",
        foco: "colapso"
    },
    {
        texto: "Seus pontos e a fase atual são exibidos aqui. Avance de fase para ganhar mais pontos! Fases mais altas aumentam a dificuldade e as recompensas.",
        foco: "statusJogo"
    },
    {
        texto: "Cuidado com os Eventos Aleatórios que podem surgir! Eles podem te ajudar ou atrapalhar. Fique de olho nas mensagens na parte inferior da tela.",
        foco: "eventos"
    },
    {
        texto: "O jogo termina se uma região colapsar e ficar sem recursos, ou se permanecer colapsada por muito tempo. Busque a vitória atingindo a Fase 10 ou o Equilíbrio Perfeito!",
        foco: "condicoesFim"
    },
    {
        texto: "Pronto para começar? Boa sorte, e lembre-se: o equilíbrio é a chave para a prosperidade!",
        foco: "final"
    }
];
let tutorialBotaoProximo;
let tutorialVistoPelaPrimeiraVez = false; // Flag para controlar se o tutorial já foi visto

let dicasAtivas = []; // Array para armazenar dicas contextuais ativas
const MAX_DICAS_SIMULTANEAS = 3; // Limite de dicas exibidas ao mesmo tempo
const TEMPO_DICA_DISPLAY = 5000; // Tempo que a dica fica visível (5 segundos)
let ultimaDicaTempo = 0; // Tempo da última dica mostrada
let dicasJaMostradas = new Set(); // Para controlar dicas que só devem aparecer uma vez

// --- SISTEMA DE CONQUISTAS ---
let conquistas = [];
let conquistasDesbloqueadasNotificacoes = []; // Para exibir notificações de conquistas desbloqueadas
const TEMPO_NOTIFICACAO_CONQUISTA = 4000; // 4 segundos

// Variáveis para checagem de conquistas de habilidade
let transfersThisSecond = 0;
let lastTransferTime = 0;
let transfersIn5Seconds = 0; // Para "Mãos Rápidas"
let tempoSemInstabilidade = 0; // Para "Sem Crises"
let tempoRecursosBaixosFrugal = 0; // Para "Frugal"
let ultimaVerificacaoFrugal = 0;

// Declaração global para 'historiaText' para que 'keyPressed' e 'desenharHistoria' possam acessá-la
let historiaText = [
    "🌍 A Conexão entre Campo e Cidade 🌱🏙️",
    "",
    "Há muito tempo, o Campo e a Cidade viviam isolados,",
    "cada um cuidando de seus próprios recursos.",
    "",
    "Mas o equilíbrio natural foi se perdendo e a conexão",
    "entre eles enfraqueceu, causando crises de recursos.",
    "",
    "Sua missão é restaurar a harmonia, ajudando a melhorar",
    "a conexão entre o campo e a cidade, trocando recursos,",
    "e garantindo que ambos cresçam juntos.",
    "",
    "Pressione ESPAÇO para continuar..."
];

/**
 * Função de inicialização do p5.js.
 * Chamada uma vez ao iniciar o sketch.
 */
function setup() {
    createCanvas(700, 510); // Cria o canvas principal do jogo
    frameRate(60); // Define o framerate para 60 FPS
    textFont('Arial'); // Define a fonte padrão

    // Inicializa o oscilador para os efeitos sonoros de transferência
    transferSound = new p5.Oscillator('sine'); // Cria um oscilador de onda senoidal
    transferSound.amp(0); // Começa com volume 0
    transferSound.start(); // Inicia o oscilador (mas sem som audível ainda)

    inicializarConquistas(); // Inicializa o array de conquistas
    criarBotoesMenu(); // Cria os botões do menu inicial
}

/**
 * Cria e posiciona os botões do menu principal.
 */
function criarBotoesMenu() {
    // Remove botões existentes para evitar duplicatas ao retornar ao menu
    if (botaoFacil) botaoFacil.remove();
    if (botaoMedio) botaoMedio.remove();
    if (botaoDificil) botaoDificil.remove();
    if (botaoInstrucoes) botaoInstrucoes.remove();
    if (botaoVoltar) botaoVoltar.remove(); // Garante que o botão voltar seja removido se existir
    if (tutorialBotaoProximo) tutorialBotaoProximo.remove(); // Remove botão do tutorial se existir
    if (botaoConquistas) botaoConquistas.remove(); // Remove botão de conquistas se existir

    botaoFacil = createButton("😌 Fácil");
    botaoMedio = createButton("😐 Médio");
    botaoDificil = createButton("😬 Difícil");
    botaoInstrucoes = createButton("❓ Instruções");
    botaoConquistas = createButton("🏆 Conquistas"); // Novo botão de conquistas

    // Posiciona os botões centralizados
    botaoFacil.position(width / 2 - 150, height / 2 + 160);
    botaoMedio.position(width / 2 - 50, height / 2 + 160);
    botaoDificil.position(width / 2 + 60, height / 2 + 160);
    botaoInstrucoes.position(width / 2 - 110, height / 2 + 220); // Ajuste de posição
    botaoConquistas.position(width / 2 + 30, height / 2 + 220); // Posição do botão de conquistas

    // Associa funções aos eventos de clique dos botões
    botaoFacil.mousePressed(() => iniciarHistoria("facil"));
    botaoMedio.mousePressed(() => iniciarHistoria("medio"));
    botaoDificil.mousePressed(() => iniciarHistoria("dificil"));
    botaoInstrucoes.mousePressed(() => mostrarInstrucoes());
    botaoConquistas.mousePressed(() => mostrarConquistas()); // Associa função ao botão de conquistas

    esconderBotoesMenu(false); // Garante que os botões do menu estejam visíveis
}

/**
 * Esconde ou mostra os botões do menu.
 * @param {boolean} esconder - Se true, esconde os botões; se false, mostra.
 */
function esconderBotoesMenu(esconder) {
    let lista = [botaoFacil, botaoMedio, botaoDificil, botaoInstrucoes, botaoConquistas]; // Inclui botão de conquistas
    lista.forEach(b => {
        if (b) { // Verifica se o botão existe
            if (esconder) b.hide();
            else b.show();
        }
    });
}

/**
 * Inicia a sequência de história do jogo.
 * @param {string} dificuldade - A dificuldade escolhida ("facil", "medio", "dificil").
 */
function iniciarHistoria(dificuldade) {
    telaAtual = "historia"; // Muda para a tela de história
    esconderBotoesMenu(true); // Esconde os botões do menu
    janelaHistoria = 0; // Reinicia a progressão da história
    dificuldadeEscolhida = dificuldade; // Armazena a dificuldade

    // Cria o botão "Voltar" para a tela de história
    botaoVoltar = createButton("🔙 Voltar");
    botaoVoltar.position(20, height - 50);
    botaoVoltar.mousePressed(() => {
        telaAtual = "menu"; // Volta para o menu
        botaoVoltar.remove(); // Remove o botão "Voltar"
        esconderBotoesMenu(false); // Mostra os botões do menu
    });
}

/**
 * Inicia o jogo com a dificuldade selecionada.
 * @param {string} dificuldade - A dificuldade escolhida ("facil", "medio", "dificil").
 */
function iniciarJogo(dificuldade) {
    telaAtual = "jogo"; // Muda para a tela de jogo
    jogoIniciado = true; // Define o flag de jogo iniciado
    tempo = 0; // Reinicia o tempo de jogo
    faseAtual = 1; // Reinicia a fase
    pontos = 0; // Reinicia os pontos
    tamanhoParaProximaFase = 150; // Reinicia o tamanho para a próxima fase

    // Reinicia as variáveis de efeito visual
    transferParticles = [];
    campoCresceuRecently = 0;
    cidadeCresceuRecently = 0;
    prodIncreaseIndicators = [];

    // Reinicia variáveis de evento aleatório
    proximoEventoTempo = 60; // Resetar para o tempo inicial
    eventoAtivo = null;
    eventoFimTempo = 0;

    // Reinicia variáveis de condição de vitória/derrota
    tempoEquilibrioPerfeito = 0;
    campoColapsadoDesde = 0;
    cidadeColapsadoDesde = 0;

    // Reinicia variáveis de dicas e tutorial
    dicasAtivas = [];
    dicasJaMostradas = new Set();
    ultimaDicaTempo = 0;

    // Reinicia variáveis para conquistas de habilidade
    transfersThisSecond = 0;
    lastTransferTime = 0;
    transfersIn5Seconds = 0;
    tempoSemInstabilidade = 0;
    tempoRecursosBaixosFrugal = 0;
    ultimaVerificacaoFrugal = 0;
    conquistasDesbloqueadasNotificacoes = []; // Limpa notificações de conquistas

    // Configurações de recursos e produção baseadas na dificuldade
    let config = {
        facil: {
            comida: 25, bens: 25, agua: 15, energiaCampo: 15,
            producaoComida: 3, producaoBens: 3, producaoAgua: 2, producaoEnergiaCampo: 2,
            tolerancia: 10, intervalo: 1500,
            producaoEnergiaCidade: 2 // Cidade produz 2 de energia (facil)
        },
        medio: {
            comida: 15, bens: 15, agua: 7, energiaCampo: 7,
            producaoComida: 2, producaoBens: 2, producaoAgua: 1, producaoEnergiaCampo: 1,
            tolerancia: 7, intervalo: 1000,
            producaoEnergiaCidade: 1 // Cidade produz 1 de energia (medio)
        },
        dificil: {
            comida: 8, bens: 8, agua: 4, energiaCampo: 4,
            producaoComida: 1, producaoBens: 1, producaoAgua: 0, producaoEnergiaCampo: 0,
            tolerancia: 5, intervalo: 700,
            producaoEnergiaCidade: 0.5 // Cidade produz 0.5 de energia (dificil)
        }
    }[dificuldade];

    limiteEstabilidade = config.tolerancia; // Define o limite de estabilidade pela dificuldade
    intervalo = config.intervalo; // Define o intervalo de atualização pela dificuldade

    // Inicializa o objeto Campo
    campo = {
        tamanho: 50,
        comida: config.comida,
        bens: 0, // Bens começam em 0 no campo, dependem da cidade
        agua: config.agua,
        energia: config.energiaCampo, // Usar energiaCampo para inicializar
        producaoComida: config.producaoComida,
        producaoAgua: config.producaoAgua,
        producaoEnergia: config.producaoEnergiaCampo, // Campo produz sua energia (pode ser 0 se a cidade for a única)
        estabilidade: 0,
        colapsado: false,
    };

    // Inicializa o objeto Cidade
    cidade = {
        tamanho: 50,
        comida: 0, // Comida começa em 0 na cidade, depende do campo
        bens: config.bens,
        agua: 0, // Água começa em 0 na cidade, depende do campo
        energia: config.energiaCampo * 0.5, // Pode começar com um pouco de energia também
        producaoBens: config.producaoBens,
        producaoAgua: 0, // Produção de água na cidade é 0 (recebe do campo)
        producaoEnergia: config.producaoEnergiaCidade, // <--- A CIDADE AGORA PRODUZ ENERGIA AQUI!
        estabilidade: 0,
        colapsado: false,
    };

    // Remove o botão "Voltar" se ele existir
    if (botaoVoltar) {
        botaoVoltar.remove();
        botaoVoltar = null;
    }

    // Garante que as alturas animadas comecem com o tamanho inicial
    alturaCampoAnimada = campo.tamanho;
    alturaCidadeAnimada = cidade.tamanho;

    // Se o tutorial ainda não foi visto, inicie-o
    if (!tutorialVistoPelaPrimeiraVez) {
        iniciarTutorial();
    }
}

/**
 * Exibe a tela de instruções do jogo.
 */
function mostrarInstrucoes() {
    telaAtual = "instrucoes"; // Muda para a tela de instruções
    esconderBotoesMenu(true); // Esconde os botões do menu

    // Cria o botão "Voltar" para a tela de instruções
    botaoVoltar = createButton("🔙 Voltar");
    botaoVoltar.position(20, height - 50);
    botaoVoltar.mousePressed(() => {
        telaAtual = "menu"; // Volta para o menu
        botaoVoltar.remove(); // Remove o botão "Voltar"
        esconderBotoesMenu(false); // Mostra os botões do menu
    });
}

/**
 * Função principal de desenho do p5.js.
 * Chamada continuamente, desenha os elementos na tela.
 */
function draw() {
    background(135, 206, 250); // Define a cor de fundo padrão (céu azul claro)

    // Lógica para alternar entre as telas do jogo
    if (telaAtual === "menu") {
        desenharMenu();
    } else if (telaAtual === "instrucoes") {
        desenharInstrucoes();
    } else if (telaAtual === "historia") {
        desenharHistoria();
    } else if (telaAtual === "tutorial") {
        desenharTutorial(); // Desenha a tela do tutorial
    } else if (telaAtual === "conquistas") { // Nova tela de conquistas
        desenharConquistas();
    } else if (telaAtual === "jogo") {
        // Atualiza a lógica do jogo a cada 'intervalo' (1 segundo, ou o tempo definido pela dificuldade)
        if (millis() - ultimaAtualizacao > intervalo) {
            atualizarLogica();
            ultimaAtualizacao = millis();
            tempo++; // Incrementa o tempo de jogo

            // Checa por eventos aleatórios a cada proximoEventoTempo segundos
            if (tempo % proximoEventoTempo === 0) {
                sortearEventoAleatorio();
            }
        }
        desenharJogo(); // Desenha os elementos da tela de jogo
        gerenciarDicasContextuais(); // Gerencia e exibe dicas contextuais
        gerenciarNotificacoesConquistas(); // Gerencia e exibe notificações de conquistas
    } else if (telaAtual === "fim") {
        desenharFim(); // Desenha a tela de fim de jogo
    } else if (telaAtual === "faseCompleta") {
        desenharFaseCompleta(); // Desenha a tela de fase completa
    } else if (telaAtual === "vitoria") {
        desenharVitoria(); // Desenha a tela de vitória
    }
}

/**
 * Desenha a sequência de história e narrativa.
 */
function desenharHistoria() {
    background(120, 180, 255); // Fundo azul mais escuro para a história

    // Desenha a caixa de texto
    fill(255);
    stroke(0);
    strokeWeight(1);
    rect(40, 40, width - 80, height - 120, 20);

    noStroke();
    fill(30);
    textAlign(LEFT, TOP);
    textSize(22);

    // Apresenta texto progressivamente
    let linhas = historiaText.slice(0, janelaHistoria + 1); // Usa a variável global historiaText
    text(linhas.join("\n"), 60, 60, width - 100, height - 140);

    // Desenha um cenário básico no fundo da história
    desenharCenarioBasico(60, height - 100);
}

/**
 * Desenha um cenário básico com árvore e prédio simplificado.
 * Usado na tela de história.
 * @param {number} x - Posição X inicial do cenário.
 * @param {number} y - Posição Y inicial do cenário.
 */
function desenharCenarioBasico(x, y) {
    push();
    translate(x, y);

    // Grama
    noStroke();
    fill(60, 180, 60);
    rect(-20, 40, 200, 30, 10);

    // Árvores simples
    fill(30, 120, 30);
    ellipse(0, 20, 40, 40);
    fill(120, 70, 20);
    rect(-10, 40, 20, 30);

    // Prédio simples
    fill(200, 200, 220);
    rect(120, 10, 40, 80, 10);
    fill(100);
    for (let i = 0; i < 3; i++) {
        for (let j = 0; j < 2; j++) {
            rect(130 + j * 15, 20 + i * 20, 10, 10);
        }
    }
    pop();
}

/**
 * Desenha a tela de menu principal do jogo.
 */
function desenharMenu() {
    // Céu com nuvens
    background(135, 206, 250);
    desenharNuvens();

    // Sol
    noStroke();
    fill(255, 230, 80);
    ellipse(width - 100, 100, 90, 90);

    // Texto título
    textAlign(CENTER);
    fill(30);
    textSize(48);
    textStyle(BOLD);
    text("🌾 Cidade & Campo 🌆", width / 2, height / 2 - 140);

    textSize(22);
    textStyle(NORMAL);
    text("Ajude a melhorar a conexão entre campo e cidade", width / 2, height / 2 - 100);

    // Desenhar cenário animado no menu
    desenharCampoDetalhado(100, height - 80);
    desenharCidadeDetalhada(350, height - 80);

    // Mensagem interativa
    fill(0, 80);
    textSize(14);
    text("Escolha a dificuldade para começar ou veja as opções", width / 2, height / 2 + 120);
}

/**
 * Desenha nuvens animadas no céu.
 */
function desenharNuvens() {
    fill(255, 255, 255, 230);
    noStroke();
    // Nuvens que se movem da direita para a esquerda
    let cx = (frameCount * 0.5) % (width + 150) - 150;
    ellipse(cx, 80, 100, 60);
    ellipse(cx + 40, 75, 80, 50);
    ellipse(cx + 80, 85, 110, 65);

    let cx2 = (frameCount * 0.3 + 300) % (width + 150) - 150;
    ellipse(cx2, 120, 120, 70);
    ellipse(cx2 + 50, 130, 90, 55);
    ellipse(cx2 + 90, 110, 130, 80);
}

/**
 * Desenha o campo com detalhes e animações.
 * Usado no menu.
 * @param {number} x - Posição X do campo.
 * @param {number} y - Posição Y do campo.
 */
function desenharCampoDetalhado(x, y) {
    push();
    translate(x, y);

    // Grama com textura
    noStroke();
    fill(60, 180, 60);
    rect(-50, 0, 100, 80, 15);

    // Plantações animadas (pequeno movimento)
    fill(0, 150, 30);
    for (let i = -40; i <= 40; i += 20) {
        ellipse(i, 20 + sin(frameCount * 0.1 + i) * 3, 12, 25);
    }

    // Árvores detalhadas
    for (let i = -30; i <= 30; i += 30) {
        // Tronco
        fill(120, 70, 20);
        rect(i, -15, 10, 35, 3);
        // Copa
        fill(30, 120, 30);
        ellipse(i + 5, -30, 40, 40);
    }
    pop();
}

/**
 * Desenha a cidade com detalhes e animações.
 * Usado no menu.
 * @param {number} x - Posição X da cidade.
 * @param {number} y - Posição Y da cidade.
 */
function desenharCidadeDetalhada(x, y) {
    push();
    translate(x, y);

    // Base da cidade
    noStroke();
    fill(200, 200, 220);
    rect(-50, 0, 100, 80, 15);

    // Prédios variados
    let alturas = [50, 60, 40, 70];
    let cores = [[150, 150, 180], [180, 180, 200], [130, 130, 160], [170, 170, 190]];
    for (let i = 0; i < 4; i++) {
        fill(...cores[i]);
        rect(-45 + i * 25, 80 - alturas[i], 20, alturas[i], 5);

        // Janelas
        fill(255, 255, 210);
        for (let j = 0; j < alturas[i] / 15; j++) {
            rect(130 + j * 15, 20 + i * 20, 10, 10);
        }
    }

    // Rua
    fill(80);
    rect(-60, 80, 120, 15, 5);

    // Carros simples animados
    let cx = (frameCount * 3) % 120 - 60; // Movimento horizontal do carro
    fill(200, 0, 0);
    rect(cx, 85, 30, 10, 3);
    fill(0);
    ellipse(cx + 5, 95, 10, 10);
    ellipse(cx + 25, 95, 10, 10);
    pop();
}

/**
 * Atualiza a lógica do jogo (produção, consumo, crescimento, colapsos, fases).
 */
function atualizarLogica() {
    // --- Lógica de Eventos Aleatórios ---
    if (eventoAtivo && tempo >= eventoFimTempo) {
        // Fim do evento: reverte os efeitos
        aplicarEfeitoEvento(eventoAtivo.tipo, false); // false para reverter
        eventoAtivo = null;
        eventoTemporario(`✅ Fim do evento!`); // Atualiza a mensagem
    }

    // Produção de recursos
    if (!campo.colapsado) {
        campo.comida += campo.producaoComida;
        campo.agua += campo.producaoAgua;
        campo.energia += campo.producaoEnergia; // Campo ainda pode produzir energia
    }
    if (!cidade.colapsado) {
        cidade.bens += cidade.producaoBens;
        cidade.energia += cidade.producaoEnergia; // CIDADE agora produz energia!
        // A cidade não produz água ou comida diretamente; ela depende das transferências do campo.
    }

    // Consumo e crescimento
    let consumiu = false; // Flag para verificar se houve consumo bem-sucedido

    // Lógica de crescimento e estabilidade da Cidade
    if (
        cidade.comida >= 1 &&
        cidade.bens >= 1 &&
        cidade.agua >= 1 &&
        cidade.energia >= 1
    ) {
        let oldCidadeTamanho = cidade.tamanho; // Guarda o tamanho antigo para verificar crescimento
        cidade.tamanho = min(cidade.tamanho + 3, 200); // Aumenta o tamanho da cidade, limitado a 200
        if (cidade.tamanho > oldCidadeTamanho) { // Se realmente cresceu
            cidadeCresceuRecently = 255; // Ativa a aura de crescimento
        }
        cidade.comida = floor(cidade.comida) - 1; // Garante que decrementa um valor inteiro
        cidade.bens = floor(cidade.bens) - 1;
        cidade.agua = floor(cidade.agua) - 1;
        cidade.energia = floor(cidade.energia) - 1;
        cidade.estabilidade = 0; // Reseta a estabilidade se consumiu
        consumiu = true;
    } else {
        cidade.estabilidade++; // Aumenta a instabilidade se não consumiu
    }

    // Lógica de crescimento e estabilidade do Campo
    if (
        campo.comida >= 1 &&
        campo.bens >= 1 &&
        campo.agua >= 1 &&
        campo.energia >= 1
    ) {
        let oldCampoTamanho = campo.tamanho; // Guarda o tamanho antigo para verificar crescimento
        campo.tamanho = min(campo.tamanho + 3, 200); // Aumenta o tamanho do campo, limitado a 200
        if (campo.tamanho > oldCampoTamanho) { // Se realmente cresceu
            campoCresceuRecently = 255; // Ativa a aura de crescimento
        }
        campo.comida = floor(campo.comida) - 1; // Garante que decrementa um valor inteiro
        campo.bens = floor(campo.bens) - 1;
        campo.agua = floor(campo.agua) - 1;
        campo.energia = floor(campo.energia) - 1;
        campo.estabilidade = 0; // Reseta a estabilidade se consumiu
        consumiu = true;
    } else {
        campo.estabilidade++; // Aumenta a instabilidade se não consumiu
    }

    // Checagem de colapsos
    if (campo.estabilidade >= limiteEstabilidade && !campo.colapsado) {
        campo.colapsado = true;
        campoColapsadoDesde = tempo; // Registra o tempo do colapso
    }
    if (cidade.estabilidade >= limiteEstabilidade && !cidade.colapsado) {
        cidade.colapsado = true;
        cidadeColapsadoDesde = tempo; // Registra o tempo do colapso
    }

    // Aumentar produção a cada 30 segundos (ciclos) se houver consumo (para garantir progresso)
    if (tempo % 30 === 0 && consumiu && tempo > 0) { // Adicionado tempo > 0 para evitar aumento no segundo 0
        if (!campo.colapsado) {
            campo.producaoComida++;
            campo.producaoAgua++;
            // campo.producaoEnergia++; // Descomente se o campo ainda produzir energia
            mostrarProducaoAumentada(120 + 20, height - 100 - alturaCampoAnimada - 20); // Posição Campo
        }
        if (!cidade.colapsado) {
            cidade.producaoBens++;
            cidade.producaoEnergia++; // Aumenta a produção de energia da cidade
            mostrarProducaoAumentada(450 + 20, height - 100 - alturaCidadeAnimada - 20); // Posição Cidade
        }
        eventoTemporario("⬆️ Produção aumentada!");
    }

    // Checar fase e pontos (Loop while para garantir que todas as fases necessárias sejam passadas)
    let somaTamanhos = campo.tamanho + cidade.tamanho;
    while (somaTamanhos >= tamanhoParaProximaFase) { // Mudança para WHILE
        faseAtual++;
        let pontosGanhos = faseAtual * 10;
        pontos += pontosGanhos; // Pontos aumentam mais a cada fase
        tamanhoParaProximaFase += 100 + (faseAtual * 10); // Aumenta o requisito de forma mais consistente e progressiva

        // Ativa a tela de "Fase Concluída"
        faseConcluidaNumero = faseAtual -1; // Guarda a fase que acabou de ser concluída
        faseConcluidaPontosGanhos = pontosGanhos;
        telaAtual = "faseCompleta";
        faseConcluidaTimer = millis(); // Inicia o timer da tela de fase completa

        // CHECAGEM DE CONQUISTAS DE FASE
        if (faseAtual === 2) desbloquearConquista("Novato Equilibrado");
        if (faseAtual === 5) desbloquearConquista("Construtor Experiente");

        // Condição para "Frugal" é checada no momento do avanço de fase
        if (tempoRecursosBaixosFrugal >= 30) {
            desbloquearConquista("Frugal");
        }
        tempoRecursosBaixosFrugal = 0; // Reseta após avanço de fase
    }

    // Animação de altura de campo e cidade
    alturaCampoAnimada = lerp(alturaCampoAnimada, campo.tamanho, 0.1);
    alturaCidadeAnimada = lerp(alturaCidadeAnimada, cidade.tamanho, 0.1);

    // --- CONDIÇÕES DE VITÓRIA ---
    // Condição de Vitória 1: Atingir a Fase 10
    if (faseAtual >= 10) {
        telaAtual = "vitoria";
        jogoIniciado = false;
        desbloquearConquista("Mestre do Equilíbrio"); // Conquista de vitória de fase
        // Conquistas de dificuldade são checadas aqui
        if (dificuldadeEscolhida === "facil") desbloquearConquista("Vitória Descontraída");
        if (dificuldadeEscolhida === "medio") desbloquearConquista("Desafio Moderado");
        if (dificuldadeEscolhida === "dificil") desbloquearConquista("A Lenda");
        return; // Sai da função para evitar outras lógicas de jogo
    }

    // Condição de Vitória 2: Equilíbrio Perfeito
    if (campo.tamanho >= 200 && cidade.tamanho >= 200) {
        tempoEquilibrioPerfeito++;
        if (tempoEquilibrioPerfeito >= 10) { // 10 segundos de equilíbrio perfeito
            telaAtual = "vitoria";
            jogoIniciado = false;
            // Conquistas de dificuldade são checadas aqui
            if (dificuldadeEscolhida === "facil") desbloquearConquista("Vitória Descontraída");
            if (dificuldadeEscolhida === "medio") desbloquearConquista("Desafio Moderado");
            if (dificuldadeEscolhida === "dificil") desbloquearConquista("A Lenda");
            return;
        }
    } else {
        tempoEquilibrioPerfeito = 0; // Reseta o contador se sair do equilíbrio
    }

    // --- CONDIÇÕES DE DERROTA ---
    // Condição de Derrota 1: Colapso Completo (todos os recursos a zero)
    if (
        (campo.colapsado && campo.comida <= 0 && campo.bens <= 0 && campo.agua <= 0 && campo.energia <= 0) ||
        (cidade.colapsado && cidade.comida <= 0 && cidade.bens <= 0 && cidade.agua <= 0 && cidade.energia <= 0)
    ) {
        telaAtual = "fim";
        jogoIniciado = false;
        return;
    }

    // Condição de Derrota 2: Dívida de Estabilidade
    if (campo.colapsado && tempo - campoColapsadoDesde >= TEMPO_PARA_DERROTA_COLAPSO) {
        telaAtual = "fim";
        jogoIniciado = false;
        return;
    }
    if (cidade.colapsado && tempo - cidadeColapsadoDesde >= TEMPO_PARA_DERROTA_COLAPSO) {
        telaAtual = "fim";
        jogoIniciado = false;
        return;
    }

    // Se uma região colapsa mas se recupera (recebe recursos), ela sai do estado de colapso
    if (campo.colapsado && (campo.comida > 0 || campo.bens > 0 || campo.agua > 0 || campo.energia > 0)) {
        campo.colapsado = false;
        campo.estabilidade = 0; // Zera a estabilidade ao recuperar
        campoColapsadoDesde = 0; // Reseta o contador de colapso
    }
    if (cidade.colapsado && (cidade.comida > 0 || cidade.bens > 0 || cidade.agua > 0 || cidade.energia > 0)) {
        cidade.colapsado = false;
        cidade.estabilidade = 0; // Zera a estabilidade ao recuperar
        cidadeColapsadoDesde = 0; // Reseta o contador de colapso da cidade
    }

    // CHECAGEM DE CONQUISTAS (chamada a cada segundo)
    checarConquistas();
}

/**
 * Exibe um texto de evento temporário na tela.
 * @param {string} texto - O texto do evento.
 */
function eventoTemporario(texto) {
    textoEvento = texto;
    eventoTimer = millis(); // Registra o tempo do evento
}

/**
 * Desenha todos os elementos da tela de jogo.
 */
function desenharJogo() {
    desenharCenarioJogo(); // Desenha o cenário de fundo do jogo

    // Desenha o Campo animado
    push();
    translate(120, height - 100); // Posição do campo
    desenharCampoAnimado(alturaCampoAnimada, campo.colapsado, campo.estabilidade); // Passa estabilidade
    pop();

    // Desenha a Cidade animada
    push();
    translate(450, height - 100); // Posição da cidade
    desenharCidadeAnimada(alturaCidadeAnimada, cidade.colapsado, cidade.estabilidade); // Passa estabilidade
    pop();

    // Exibe informações de recursos e status (Campo)
    fill(30);
    noStroke();
    textSize(16);
    textAlign(LEFT);

    text("🌾 Campo", 50, 30);

    // Recurso Comida (Campo)
    let producaoComidaCampo = campo.producaoComida - 1; // Produção vs consumo (1 por ciclo)
    drawResourceLine("Comida", campo.comida, producaoComidaCampo, 50, 50, campo.colapsado);

    // Recurso Bens (Campo) - Começa em 0, recebe da cidade
    let producaoBensCampo = 0 - 1; // Bens são só consumidos no campo, não produzidos
    drawResourceLine("Bens", campo.bens, producaoBensCampo, 50, 70, campo.colapsado);

    // Recurso Água (Campo)
    let producaoAguaCampo = campo.producaoAgua - 1;
    drawResourceLine("Água", campo.agua, producaoAguaCampo, 50, 90, campo.colapsado);

    // Recurso Energia (Campo)
    let producaoEnergiaCampo = campo.producaoEnergia - 1;
    drawResourceLine("Energia", campo.energia, producaoEnergiaCampo, 50, 110, campo.colapsado);


    // Produção (sem pulsação)
    fill(30);
    text(`Produção Comida: ${campo.producaoComida}`, 50, 130);
    text(`Produção Água: ${campo.producaoAgua}`, 50, 150);
    text(`Produção Energia: ${campo.producaoEnergia}`, 50, 170);


    if (campo.colapsado) {
        fill(255, 80, 80); // Cor vermelha para colapsado
        textSize(20);
        text("🚨 COLAPSADO!", 50, 190);
        if (campoColapsadoDesde > 0) { // Mostra timer se colapsado
            let tempoRestante = TEMPO_PARA_DERROTA_COLAPSO - (tempo - campoColapsadoDesde);
            if (tempoRestante > 0) {
                fill(255, 165, 0); // Laranja para o tempo
                text(`Recupere em: ${tempoRestante}s`, 50, 215);
            }
        }
    } else if (campo.estabilidade > limiteEstabilidade / 2) {
        // Alerta de instabilidade antes do colapso total
        let alpha = map(sin(frameCount * 0.1), -1, 1, 100, 255); // Efeito de piscar mais intenso
        fill(255, 165, 0, alpha); // Cor laranja para instável
        textSize(18);
        text("⚠️ Instável!", 50, 190);
    }

    // Exibe informações de recursos e status (Cidade)
    fill(30);
    text("🏙️ Cidade", 380, 30);

    // Recurso Comida (Cidade) - Começa em 0, recebe do campo
    let producaoComidaCidade = 0 - 1; // Comida é só consumida na cidade
    drawResourceLine("Comida", cidade.comida, producaoComidaCidade, 380, 50, cidade.colapsado);

    // Recurso Bens (Cidade)
    let producaoBensCidade = cidade.producaoBens - 1;
    drawResourceLine("Bens", cidade.bens, producaoBensCidade, 380, 70, cidade.colapsado);

    // Recurso Água (Cidade) - Começa em 0, recebe do campo
    let producaoAguaCidade = 0 - 1; // Água é só consumida na cidade
    drawResourceLine("Água", cidade.agua, producaoAguaCidade, 380, 90, cidade.colapsado);

    // Recurso Energia (Cidade)
    let producaoEnergiaCidade = cidade.producaoEnergia - 1;
    drawResourceLine("Energia", cidade.energia, producaoEnergiaCidade, 380, 110, cidade.colapsado);


    // Produção (sem pulsação)
    fill(30);
    text(`Produção Bens: ${cidade.producaoBens}`, 380, 130);
    text(`Produção Energia: ${cidade.producaoEnergia}`, 380, 150);


    if (cidade.colapsado) {
        fill(255, 80, 80); // Cor vermelha para colapsado
        textSize(20);
        text("🚨 COLAPSADO!", 380, 180); // Ajuste de posição para não sobrepor
        if (cidadeColapsadoDesde > 0) { // Mostra timer se colapsado
            let tempoRestante = TEMPO_PARA_DERROTA_COLAPSO - (tempo - cidadeColapsadoDesde);
            if (tempoRestante > 0) {
                fill(255, 165, 0); // Laranja para o tempo
                text(`Recupere em: ${tempoRestante}s`, 380, 205);
            }
        }
    } else if (cidade.estabilidade > limiteEstabilidade / 2) {
        // Alerta de instabilidade antes do colapso total
        let alpha = map(sin(frameCount * 0.1), -1, 1, 100, 255); // Efeito de piscar mais intenso
        fill(255, 165, 0, alpha); // Cor laranja para instável
        textSize(18);
        text("⚠️ Instável!", 380, 180); // Ajuste de posição
    }

    // Exibe informações gerais do jogo (tempo, fase, pontos)
    fill(0);
    textSize(18);
    textAlign(CENTER);
    text(`⏱️ Tempo: ${tempo} seg`, width - 100, 30);
    text(`🛡️ Fase: ${faseAtual}`, width - 100, 60);
    text(`⭐ Pontos: ${pontos}`, width - 100, 90);

    // Barra de progresso para a próxima fase
    let progresso = map(campo.tamanho + cidade.tamanho, 0, tamanhoParaProximaFase, 0, 200);
    stroke(0);
    noFill();
    rect(width - 220, 110, 200, 20, 10);
    noStroke();
    fill(100, 200, 100);
    rect(width - 220, 110, progresso, 20, 10);

    // Indicador de Equilíbrio Perfeito
    if (campo.tamanho >= 200 && cidade.tamanho >= 200) {
        let alphaBalance = map(sin(frameCount * 0.05), -1, 1, 150, 255);
        fill(0, 180, 0, alphaBalance); // Verde pulsante
        textSize(20);
        text(`✨ Equilíbrio Perfeito! (${10 - tempoEquilibrioPerfeito}s restantes)`, width / 2, height / 2 - 150);
    }


    // Exibe texto de evento temporário (se houver) OU evento ativo
    if (millis() - eventoTimer < 3000 && textoEvento !== "") {
        fill(0, 150); // Fundo semi-transparente para o texto do evento
        rect(width / 2 - 150, height - 80, 300, 40, 20);
        fill(255);
        textSize(16);
        textAlign(CENTER, CENTER);
        text(textoEvento, width / 2, height - 60);
    } else if (eventoAtivo) { // Se um evento está ativo
        fill(0, 150);
        rect(width / 2 - 180, height - 80, 360, 40, 20);
        fill(255, 255, 0); // Amarelo para eventos
        textSize(16);
        textAlign(CENTER, CENTER);
        text(`⚠️ Evento: ${eventoAtivo.nome} (${eventoFimTempo - tempo}s restantes)`, width / 2, height - 60);
    }


    // Atualiza e desenha partículas de transferência
    for (let i = transferParticles.length - 1; i >= 0; i--) {
        transferParticles[i].update();
        transferParticles[i].display();
        if (transferParticles[i].life <= 0 || dist(transferParticles[i].x, transferParticles[i].y, transferParticles[i].targetX, transferParticles[i].targetY) < transferParticles[i].speed) {
            transferParticles.splice(i, 1); // Remove partículas que desapareceram ou chegaram perto do destino
        }
    }

    // Atualiza e desenha indicadores de aumento de produção
    for (let i = prodIncreaseIndicators.length - 1; i >= 0; i--) {
        prodIncreaseIndicators[i].update();
        prodIncreaseIndicators[i].display();
        if (prodIncreaseIndicators[i].alpha <= 0) {
            prodIncreaseIndicators.splice(i, 1);
        }
    }


    // Exibe instruções rápidas de controle
    fill(50);
    textSize(14);
    textAlign(LEFT);
    text("Controles:", 50, height - 90);
    text("C - Transferir Comida: Campo → Cidade", 50, height - 70);
    text("B - Transferir Bens: Cidade → Campo", 50, height - 50);
    text("A - Transferir Água: Campo → Cidade", 320, height - 70);
    text("E - Transferir Energia: Cidade → Campo", 320, height - 50); // Instrução consistente com a lógica

    // Desenha dicas ativas
    desenharDicasContextuais();
}

/**
 * Desenha uma linha de recurso com indicador de produção/consumo.
 * @param {string} nome - Nome do recurso.
 * @param {number} valor - Valor atual do recurso.
 * @param {number} saldoProducao - Produção líquida (produção - consumo).
 * @param {number} x - Posição X.
 * @param {number} y - Posição Y.
 * @param {boolean} colapsado - Se a região está colapsada.
 */
function drawResourceLine(nome, valor, saldoProducao, x, y, colapsado) {
    let textColor = color(30);
    let arrow = "";
    let arrowColor = color(30);

    if (valor.toFixed(0) < 3 && !colapsado) {
        let alpha = map(sin(frameCount * 0.15), -1, 1, 150, 255);
        textColor = color(255, 80, 80, alpha); // Pisca vermelho se baixo
    }

    if (saldoProducao > 0) {
        arrow = "⬆️";
        arrowColor = color(0, 150, 0); // Verde para superávit
    } else if (saldoProducao < 0) {
        arrow = "⬇️";
        arrowColor = color(200, 0, 0); // Vermelho para déficit
    } else {
        arrow = "➡️";
        arrowColor = color(100); // Cinza para neutro
    }

    fill(textColor);
    text(`${nome}: ${valor.toFixed(0)}`, x, y);

    fill(arrowColor);
    textSize(12); // Menor para a seta
    text(arrow, x + textWidth(`${nome}: ${valor.toFixed(0)}`) + 5, y + 2); // Posição da seta
    textSize(16); // Volta ao tamanho normal
}


/**
 * Desenha a representação animada do Campo.
 * @param {number} altura - Altura atual do campo (para animação).
 * @param {boolean} colapsado - Se o campo está colapsado.
 * @param {number} estabilidade - O nível de estabilidade do campo.
 */
function desenharCampoAnimado(altura, colapsado, estabilidade) {
    push();
    // Brilho de crescimento
    if (campoCresceuRecently > 0) {
        noStroke();
        let alphaGrow = map(campoCresceuRecently, 0, 255, 0, 150);
        fill(150, 255, 150, alphaGrow); // Verde claro pulsante
        ellipse(0, -altura / 2, 120, altura + 20); // Uma aura
        campoCresceuRecently -= 5;
    }

    // Base do campo (grama) - a altura muda para simular crescimento
    noStroke();
    fill(50, 150, 50);
    rect(-50, 0, 100, -altura, 20);

    // Árvore detalhada
    fill(110, 70, 20); // Tronco
    rect(-15, -altura + 30, 10, 30, 4);
    fill(20, 130, 20); // Copa
    ellipse(-10, -altura + 15, 50, 50);

    // Plantação animada (pequeno movimento oscilante)
    fill(0, 160, 30);
    for (let i = -40; i <= 40; i += 20) {
        ellipse(i, -altura + 55 + sin(frameCount * 0.1 + i) * 3, 15, 30);
    }

    // Efeito visual quando o campo está colapsado ou instável
    if (colapsado) {
        fill(255, 0, 0, 100); // Camada vermelha semi-transparente
        rect(-50, 0, 100, -altura, 20);

        // Fumaça/Poeira de colapso
        for(let i = 0; i < 3; i++) {
            fill(80, 80, 80, map(sin(frameCount * 0.1 + i*5), -1, 1, 30, 100)); // Pulsa o alpha
            ellipse(random(-40, 40), random(-altura + 10, -10), random(10, 25), random(10, 25));
        }
    } else if (estabilidade > limiteEstabilidade / 2) {
        // Fumaça/Poeira de instabilidade leve
        for(let i = 0; i < 2; i++) {
            fill(120, 90, 0, map(sin(frameCount * 0.08 + i*5), -1, 1, 20, 80)); // Laranja acinzentado pulsante
            ellipse(random(-30, 30), random(-altura + 20, 0), random(8, 20), random(8, 20));
        }
    }
    pop();
}

/**
 * Desenha a representação animada da Cidade.
 * @param {number} altura - Altura atual da cidade (para animação).
 * @param {boolean} colapsado - Se a cidade está colapsada.
 * @param {number} estabilidade - O nível de estabilidade da cidade.
 */
function desenharCidadeAnimada(altura, colapsado, estabilidade) {
    push();
    // Brilho de crescimento
    if (cidadeCresceuRecently > 0) {
        noStroke();
        let alphaGrow = map(cidadeCresceuRecently, 0, 255, 0, 150);
        fill(150, 150, 255, alphaGrow); // Azul claro pulsante
        ellipse(0, -altura / 2, 120, altura + 20); // Uma aura
        cidadeCresceuRecently -= 5;
    }

    // Base da cidade (concreto) - a altura muda para simular crescimento
    noStroke();
    fill(180, 180, 190);
    rect(-50, 0, 100, -altura, 20);

    // Prédios variados animados
    let alturasEdificios = [altura * 0.7, altura * 0.9, altura * 0.5, altura * 0.8]; // Usar nova variável para não confundir
    let cores = [[140, 140, 180], [170, 170, 190], [120, 120, 160], [160, 160, 190]];
    for (let i = 0; i < 4; i++) {
        fill(...cores[i]);
        rect(-45 + i * 25, 0 - alturasEdificios[i], 20, alturasEdificios[i], 5);

        // Janelas piscando (animação de luzes)
        fill(255, 255, 210, 180 + 50 * sin(frameCount * 0.2 + i));
        for (let j = 0; j < alturasEdificios[i] / 15; j++) {
            rect(-43 + i * 25, 0 - alturasEdificios[i] + 5 + j * 15, 12, 10, 2);
        }
    }

    // Rua
    fill(70);
    rect(-60, 0, 120, 15, 5);

    // Carro animado
    let cx = (frameCount * 5) % 120 - 60; // Movimento horizontal do carro
    fill(220, 0, 0);
    rect(cx, 5, 30, 10, 3);
    fill(0);
    ellipse(cx + 5, 15, 10, 10);
    ellipse(cx + 25, 15, 10, 10);

    // Efeito visual quando a cidade está colapsada ou instável
    if (colapsado) {
        fill(255, 0, 0, 120); // Camada vermelha semi-transparente
        rect(-50, 0, 100, -altura, 20);

        // Fumaça/Poeira de colapso
        for(let i = 0; i < 3; i++) {
            fill(80, 80, 80, map(sin(frameCount * 0.1 + i*5), -1, 1, 30, 100)); // Pulsa o alpha
            ellipse(random(-40, 40), random(-altura + 10, -10), random(10, 25), random(10, 25));
        }
    } else if (estabilidade > limiteEstabilidade / 2) {
        // Fumaça/Poeira de instabilidade leve
        for(let i = 0; i < 2; i++) {
            fill(120, 90, 0, map(sin(frameCount * 0.08 + i*5), -1, 1, 20, 80)); // Laranja acinzentado pulsante
            ellipse(random(-30, 30), random(-altura + 20, 0), random(8, 20), random(8, 20));
        }
    }
    pop();
}

/**
 * Desenha o cenário de fundo para a tela de jogo.
 */
function desenharCenarioJogo() {
    // Céu
    background(135, 206, 250);

    // Sol e nuvens
    desenharNuvens();
    fill(255, 230, 80);
    ellipse(width - 100, 100, 90, 90);

    // Grama geral na parte inferior da tela
    noStroke();
    fill(80, 200, 80, 120);
    rect(0, height - 70, width, 70);

    // Linha separando visualmente o campo e a cidade
    stroke(100);
    strokeWeight(2);
    line(width / 2, height - 150, width / 2, height); // Linha vertical
    noStroke();
}

/**
 * Desenha a tela de instruções do jogo.
 */
function desenharInstrucoes() {
    background(240); // Fundo claro para as instruções

    fill(30);
    textAlign(LEFT, TOP);
    textSize(24);
    text("Instruções", 20, 20);

    textSize(16);
    text(
        `Neste jogo, você controla a troca e crescimento entre duas regiões:\n\n` +
        "🌾 Campo - produz comida, água e (opcionalmente) energia\n" +
        "🏙️ Cidade - produz bens e energia\n\n" +
        "Seu objetivo é manter o equilíbrio entre os recursos de ambas para que cresçam.\n" +
        "Se um lado colapsar (sem recursos), o jogo termina.\n\n" +
        "Controles:\n" +
        "- C: Transferir Comida: Campo → Cidade\n" +
        "- B: Transferir Bens: Cidade → Campo\n" +
        "- A: Transferir Água: Campo → Cidade\n" +
        "- E: Transferir Energia: Cidade → Campo\n\n" + // Linha da instrução
        "Conforme o jogo avança, a produção aumenta, e você sobe de fase, ganhando pontos.\n\n" +
        "❗ Fique atento aos **Eventos Aleatórios** que podem ocorrer e afetar o jogo!\n\n" +
        "Condições de Vitória:\n" +
        " - Alcançar a **Fase 10**.\n" +
        " - Manter o Campo e a Cidade no **tamanho máximo (200)** por **10 segundos**.\n\n" +
        "Condições de Derrota:\n" +
        " - Um lado **colapsar e ficar sem recursos**.\n" +
        " - Um lado permanecer **colapsado por 30 segundos** sem se recuperar.",
        20,
        60,
        width - 40,
        height - 80
    );

    // Garante que o botão voltar esteja visível
    if (botaoVoltar) botaoVoltar.show();
}

/**
 * Desenha a tela de fim de jogo (Game Over).
 */
function desenharFim() {
    background(50, 10, 10); // Fundo escuro avermelhado para game over

    fill(255, 80, 80); // Cor vermelha para o texto "Game Over"
    textAlign(CENTER, CENTER);
    textSize(48);
    text("🚨 GAME OVER 🚨", width / 2, height / 2 - 40);

    fill(255); // Cor branca para as informações de pontuação
    textSize(22);
    text(`Você alcançou a fase ${faseAtual} e fez ${pontos} pontos!`, width / 2, height / 2 + 10);

    textSize(18);
    text("Pressione R para reiniciar", width / 2, height / 2 + 60);
}

/**
 * Desenha a tela de "Fase Concluída".
 */
function desenharFaseCompleta() {
    // Fundo animado (transição suave)
    let alpha = map(millis() - faseConcluidaTimer, 0, 2000, 255, 0); // Fade out em 2 segundos
    background(100, 200, 100, alpha); // Verde claro com fade out

    fill(255, 255, 255, alpha); // Texto também com fade out
    textAlign(CENTER, CENTER);
    textSize(48);
    textStyle(BOLD);
    text(`🎉 FASE ${faseConcluidaNumero} COMPLETA! 🎉`, width / 2, height / 2 - 40);

    textSize(28);
    text(`⭐ +${faseConcluidaPontosGanhos} PONTOS! ⭐`, width / 2, height / 2 + 20);

    // Volta para o jogo após um tempo
    if (millis() - faseConcluidaTimer > 2500) { // Exibe por 2.5 segundos
        telaAtual = "jogo";
    }
}

/**
 * Desenha a tela de vitória.
 */
function desenharVitoria() {
    background(80, 200, 255); // Fundo azul claro festivo

    fill(255, 255, 0); // Amarelo brilhante para o texto
    textAlign(CENTER, CENTER);
    textSize(48);
    textStyle(BOLD);
    text("🏆 VITÓRIA! 🏆", width / 2, height / 2 - 60);

    fill(255);
    textSize(28);
    text(`Você restaurou a harmonia!`, width / 2, height / 2);

    textSize(22);
    text(`Total de Pontos: ${pontos}`, width / 2, height / 2 + 40);
    text(`Fase Final: ${faseAtual}`, width / 2, height / 2 + 70);

    textSize(18);
    text("Pressione R para reiniciar", width / 2, height / 2 + 120);

    // Confetes caindo
    for (let i = 0; i < 50; i++) {
        noStroke();
        fill(random(255), random(255), random(255), 180);
        rect(random(width), (frameCount * 5 + i * 10) % (height + 20) - 20, 10, 10);
    }
}

/**
 * Inicia o tutorial.
 */
function iniciarTutorial() {
    telaAtual = "tutorial";
    tutorialAtivo = true;
    tutorialStep = 0;
    tutorialVistoPelaPrimeiraVez = true; // Marca que o tutorial foi visto
    desbloquearConquista("Primeiros Passos"); // Desbloqueia a conquista de tutorial

    // Cria o botão "Próximo" para o tutorial
    tutorialBotaoProximo = createButton("Próximo ▶️");
    tutorialBotaoProximo.position(width - 150, height - 50);
    tutorialBotaoProximo.mousePressed(proximoPassoTutorial);
}

/**
 * Desenha a tela do tutorial.
 */
function desenharTutorial() {
    background(180, 220, 255); // Fundo azul claro para o tutorial

    let currentStep = tutorialStepsData[tutorialStep];
    let focusRect = { x: 0, y: 0, w: 0, h: 0 }; // Área a ser focada

    // Desenha o jogo por baixo, mas com um overlay
    push();
    if (currentStep.foco !== "geral" && currentStep.foco !== "final" && currentStep.foco !== "condicoesFim") {
        desenharJogo(); // Desenha a tela do jogo como base
    } else {
        desenharCenarioJogo(); // Desenha apenas o cenário para os passos gerais
        // Desenha campo e cidade estáticos para os passos gerais/finais do tutorial
        push();
        translate(120, height - 100);
        desenharCampoAnimado(campo.tamanho, false, 0);
        pop();
        push();
        translate(450, height - 100);
        desenharCidadeAnimada(cidade.tamanho, false, 0);
        pop();
    }
    fill(0, 0, 0, 150); // Overlay escuro
    rect(0, 0, width, height);
    pop();


    // Define a área de foco e desenha destaque
    if (currentStep.foco === "campoInfo") {
        focusRect = { x: 40, y: 15, w: 250, h: 220 };
    } else if (currentStep.foco === "cidadeInfo") {
        focusRect = { x: 370, y: 15, w: 250, h: 220 };
    } else if (currentStep.foco === "consumo") {
        focusRect = { x: 0, y: 0, w: width, h: height }; // Não há foco visual específico, é uma ideia
    } else if (currentStep.foco === "controles") {
        focusRect = { x: 40, y: height - 100, w: width - 80, h: 90 };
    } else if (currentStep.foco === "colapso") {
        focusRect = { x: 0, y: 180, w: width, h: 70 }; // Área das mensagens de colapso
    } else if (currentStep.foco === "statusJogo") {
        focusRect = { x: width - 250, y: 15, w: 240, h: 140 };
    } else if (currentStep.foco === "eventos") {
        focusRect = { x: width / 2 - 200, y: height - 90, w: 400, h: 70 };
    } else if (currentStep.foco === "condicoesFim") {
        focusRect = { x: 0, y: 0, w: width, h: height }; // Sem foco específico, explica o fim
    }


    if (focusRect.w > 0) {
        // "Buraco" no overlay escuro
        erase(); // Começa a apagar o que foi desenhado
        rect(focusRect.x, focusRect.y, focusRect.w, focusRect.h, 10);
        noErase(); // Para de apagar
        // Desenha uma borda para o foco
        stroke(255, 255, 0); // Borda amarela
        strokeWeight(4);
        rect(focusRect.x, focusRect.y, focusRect.w, focusRect.h, 10);
    }

    // Desenha a caixa de texto do tutorial
    fill(255, 255, 220); // Cor clara para a caixa de texto
    stroke(0);
    strokeWeight(1);
    let boxY = (focusRect.w > 0 && focusRect.y < height / 2) ? height / 2 : 40; // Posiciona a caixa longe do foco
    rect(40, boxY, width - 80, height - boxY - 60, 20);

    fill(30);
    textAlign(LEFT, TOP);
    textSize(20);
    text(currentStep.texto, 60, boxY + 20, width - 100, height - boxY - 80);

    // Texto de "Passo X de Y"
    textSize(14);
    textAlign(RIGHT);
    text(`${tutorialStep + 1}/${tutorialStepsData.length}`, width - 60, boxY + 20);
}

/**
 * Avança para o próximo passo do tutorial.
 */
function proximoPassoTutorial() {
    tutorialStep++;
    if (tutorialStep >= tutorialStepsData.length) {
        // Fim do tutorial, começa o jogo
        tutorialAtivo = false;
        tutorialBotaoProximo.remove(); // Remove o botão "Próximo"
        telaAtual = "jogo";
        // Re-inicia o jogo para garantir que tudo esteja limpo após o tutorial
        iniciarJogo(dificuldadeEscolhida);
    }
}

/**
 * Gerencia a exibição de dicas contextuais durante o jogo.
 */
function gerenciarDicasContextuais() {
    // Remove dicas expiradas
    dicasAtivas = dicasAtivas.filter(d => millis() - d.startTime < TEMPO_DICA_DISPLAY);

    // Adiciona novas dicas com base nas condições do jogo
    if (millis() - ultimaDicaTempo > 3000 && dicasAtivas.length < MAX_DICAS_SIMULTANEAS) { // Evita spam de dicas
        // Dica: Campo com pouca comida
        if (campo.comida < 5 && !campo.colapsado && !dicasJaMostradas.has("campoComidaBaixa")) {
            dicasAtivas.push({ id: "campoComidaBaixa", texto: "⚠️ Campo precisa de Comida! Transfira Bens da Cidade (tecla B).", startTime: millis() });
            dicasJaMostradas.add("campoComidaBaixa");
            ultimaDicaTempo = millis();
        }
        // Dica: Cidade com pouca comida
        else if (cidade.comida < 5 && !cidade.colapsado && !dicasJaMostradas.has("cidadeComidaBaixa")) {
            dicasAtivas.push({ id: "cidadeComidaBaixa", texto: "⚠️ Cidade precisa de Comida! Transfira do Campo (tecla C).", startTime: millis() });
            dicasJaMostradas.add("cidadeComidaBaixa");
            ultimaDicaTempo = millis();
        }
        // Dica: Campo com pouca água
        else if (campo.agua < 5 && !campo.colapsado && !dicasJaMostradas.has("campoAguaBaixa")) {
            // Não há dica para Campo com pouca água que venha da cidade diretamente, pois campo produz água.
            // Poderia ser uma dica para verificar a produção de água do campo.
            dicasAtivas.push({ id: "campoAguaBaixa", texto: "⚠️ Campo precisa de Água! Aumente a produção de água do Campo.", startTime: millis() });
            dicasJaMostradas.add("campoAguaBaixa");
            ultimaDicaTempo = millis();
        }
        // Dica: Cidade com pouca água
        else if (cidade.agua < 5 && !cidade.colapsado && !dicasJaMostradas.has("cidadeAguaBaixa")) {
            dicasAtivas.push({ id: "cidadeAguaBaixa", texto: "⚠️ Cidade precisa de Água! Transfira do Campo (tecla A).", startTime: millis() });
            dicasJaMostradas.add("cidadeAguaBaixa");
            ultimaDicaTempo = millis();
        }
        // Dica: Campo com poucos bens
        else if (campo.bens < 5 && !campo.colapsado && !dicasJaMostradas.has("campoBensBaixos")) {
            dicasAtivas.push({ id: "campoBensBaixos", texto: "⚠️ Campo precisa de Bens! Transfira da Cidade (tecla B).", startTime: millis() });
            dicasJaMostradas.add("campoBensBaixos");
            ultimaDicaTempo = millis();
        }
        // Dica: Cidade com poucos bens
        else if (cidade.bens < 5 && !cidade.colapsado && !dicasJaMostradas.has("cidadeBensBaixos")) {
            // Cidade produz bens, então a dica seria para verificar a produção
            dicasAtivas.push({ id: "cidadeBensBaixos", texto: "⚠️ Cidade precisa de Bens! Aumente a produção de bens da Cidade.", startTime: millis() });
            dicasJaMostradas.add("cidadeBensBaixos");
            ultimaDicaTempo = millis();
        }
        // Dica: Campo com pouca energia
        else if (campo.energia < 5 && !campo.colapsado && !dicasJaMostradas.has("campoEnergiaBaixa")) {
            dicasAtivas.push({ id: "campoEnergiaBaixa", texto: "⚠️ Campo precisa de Energia! Transfira da Cidade (tecla E).", startTime: millis() });
            dicasJaMostradas.add("campoEnergiaBaixa");
            ultimaDicaTempo = millis();
        }
        // Dica: Cidade com pouca energia
        else if (cidade.energia < 5 && !cidade.colapsado && !dicasJaMostradas.has("cidadeEnergiaBaixa")) {
            // Cidade produz energia, então a dica seria para verificar a produção
            dicasAtivas.push({ id: "cidadeEnergiaBaixa", texto: "⚠️ Cidade precisa de Energia! Aumente a produção de energia da Cidade.", startTime: millis() });
            dicasJaMostradas.add("cidadeEnergiaBaixa");
            ultimaDicaTempo = millis();
        }
        // Dica: Campo instável
        else if (campo.estabilidade >= limiteEstabilidade / 2 && !campo.colapsado && !dicasJaMostradas.has("campoInstavel")) {
            dicasAtivas.push({ id: "campoInstavel", texto: "🔥 Campo instável! Transfira recursos para ele rapidamente!", startTime: millis() });
            dicasJaMostradas.add("campoInstavel");
            ultimaDicaTempo = millis();
        }
        // Dica: Cidade instável
        else if (cidade.estabilidade >= limiteEstabilidade / 2 && !cidade.colapsado && !dicasJaMostradas.has("cidadeInstavel")) {
            dicasAtivas.push({ id: "cidadeInstavel", texto: "🔥 Cidade instável! Transfira recursos para ela rapidamente!", startTime: millis() });
            dicasJaMostradas.add("cidadeInstavel");
            ultimaDicaTempo = millis();
        }
        // Dica: Campo colapsado
        else if (campo.colapsado && !dicasJaMostradas.has("campoColapsado")) {
            dicasAtivas.push({ id: "campoColapsado", texto: "🚨 Campo colapsado! Recupere-o antes que seja tarde!", startTime: millis() });
            dicasJaMostradas.add("campoColapsado");
            ultimaDicaTempo = millis();
        }
        // Dica: Cidade colapsada
        else if (cidade.colapsado && !dicasJaMostradas.has("cidadeColapsada")) {
            dicasAtivas.push({ id: "cidadeColapsada", texto: "🚨 Cidade colapsada! Recupere-a antes que seja tarde!", startTime: millis() });
            dicasJaMostradas.add("cidadeColapsada");
            ultimaDicaTempo = millis();
        }
    }
}

/**
 * Desenha as dicas contextuais ativas na tela.
 */
function desenharDicasContextuais() {
    let initialY = 10; // Posição Y inicial para as dicas
    let spacing = 35; // Espaçamento entre as dicas

    for (let i = 0; i < dicasAtivas.length; i++) {
        let dica = dicasAtivas[i];
        let alpha = map(millis() - dica.startTime, 0, TEMPO_DICA_DISPLAY, 255, 0); // Fade out

        push();
        translate(width / 2, initialY + i * spacing);
        fill(50, 50, 50, alpha); // Fundo da dica
        rect(-textWidth(dica.texto) / 2 - 10, -15, textWidth(dica.texto) + 20, 30, 5);
        fill(255, 255, 150, alpha); // Cor do texto da dica
        textSize(14);
        textAlign(CENTER, CENTER);
        text(dica.texto, 0, 0);
        pop();
    }
}


/**
 * Função chamada uma vez quando uma tecla é pressionada.
 * Lida com as transferências de recursos e reinício do jogo.
 */
function keyPressed() {
    // Lógica de transferência de recursos apenas durante o jogo
    if (telaAtual === "jogo" && jogoIniciado) {
        let keyLower = key.toLowerCase(); // Converte a tecla para minúscula para facilitar a comparação
        let transferred = false; // Flag para verificar se uma transferência ocorreu
        let targetWasCollapsed = false; // Flag para verificar se o alvo da transferência estava colapsado

        // Coordenadas aproximadas do centro do Campo e da Cidade para partículas
        const campoCenterX = 120;
        const campoCenterY = height - 100 - (campo.tamanho / 2);
        const cidadeCenterX = 450;
        const cidadeCenterY = height - 100 - (cidade.tamanho / 2);

        // Atualiza contador para "Mãos Rápidas"
        if (millis() - lastTransferTime < 5000) { // Dentro da janela de 5 segundos
            transfersIn5Seconds++;
        } else {
            transfersIn5Seconds = 1; // Reinicia se for a primeira transferência após 5s
        }
        lastTransferTime = millis();


        if (keyLower === 'c') {
            // Campo para cidade: comida
            if (campo.comida >= 1) {
                if (cidade.colapsado) targetWasCollapsed = true;
                campo.comida = floor(campo.comida) - 1;
                cidade.comida = ceil(cidade.comida) + 1;
                eventoTemporario("🍎 Comida +1 (para Cidade)"); // Adicionado o contador de transferência
                transferred = true;
                if (targetWasCollapsed) {
                    cidade.colapsado = false;
                    cidade.estabilidade = 0;
                    cidadeColapsadoDesde = 0; // Reseta o contador de colapso da cidade
                    eventoTemporario("🏙️ Cidade recuperada!");
                }
                for (let i = 0; i < 5; i++) {
                    transferParticles.push(new TransferParticle(
                        campoCenterX + random(-20, 20), campoCenterY + random(-20, 20),
                        cidadeCenterX + random(-10, 10), cidadeCenterY + random(-10, 10),
                        color(255, 100, 100), 'comida' // Vermelho para comida
                    ));
                }
            } else {
                eventoTemporario("Campo não tem comida suficiente!");
            }
        } else if (keyLower === 'b') {
            // Cidade para campo: bens
            if (cidade.bens >= 1) {
                if (campo.colapsado) targetWasCollapsed = true;
                cidade.bens = floor(cidade.bens) - 1;
                campo.bens = ceil(campo.bens) + 1;
                eventoTemporario("🔧 Bens +1 (para Campo)"); // Adicionado o contador de transferência
                transferred = true;
                if (targetWasCollapsed) {
                    campo.colapsado = false;
                    campo.estabilidade = 0;
                    campoColapsadoDesde = 0; // Reseta o contador de colapso do campo
                    eventoTemporario("🌱 Campo recuperado!");
                }
                for (let i = 0; i < 5; i++) {
                    transferParticles.push(new TransferParticle(
                        cidadeCenterX + random(-20, 20), cidadeCenterY + random(-20, 20),
                        campoCenterX + random(-10, 10), campoCenterY + random(-10, 10),
                        color(139, 69, 19), 'bens' // Marrom para bens
                    ));
                }
            } else {
                eventoTemporario("Cidade não tem bens suficientes!");
            }
        } else if (keyLower === 'a') {
            // Campo para cidade: água
            if (campo.agua >= 1) {
                if (cidade.colapsado) targetWasCollapsed = true;
                campo.agua = floor(campo.agua) - 1;
                cidade.agua = ceil(cidade.agua) + 1;
                eventoTemporario("💧 Água +1 (para Cidade)"); // Adicionado o contador de transferência
                transferred = true;
                if (targetWasCollapsed) {
                    cidade.colapsado = false;
                    cidade.estabilidade = 0;
                    cidadeColapsadoDesde = 0; // Reseta o contador de colapso da cidade
                    eventoTemporario("🏙️ Cidade recuperada!");
                }
                for (let i = 0; i < 5; i++) {
                    transferParticles.push(new TransferParticle(
                        campoCenterX + random(-20, 20), campoCenterY + random(-20, 20),
                        cidadeCenterX + random(-10, 10), cidadeCenterY + random(-10, 10),
                        color(100, 150, 255), 'agua' // Azul para água
                    ));
                }
            } else {
                eventoTemporario("Campo não tem água suficiente!");
            }
        } else if (keyLower === 'e') {
            // CIDADE para campo: energia (Alinhado com a instrução na tela e produção da cidade)
            if (cidade.energia >= 1) {
                if (campo.colapsado) targetWasCollapsed = true;
                cidade.energia = floor(cidade.energia) - 1;
                campo.energia = ceil(campo.energia) + 1;
                eventoTemporario("⚡ Energia +1 (para Campo)"); // Adicionado o contador de transferência
                transferred = true;
                if (targetWasCollapsed) {
                    campo.colapsado = false;
                    campo.estabilidade = 0;
                    campoColapsadoDesde = 0; // Reseta o contador de colapso do campo
                    eventoTemporario("🌱 Campo recuperado!");
                }
                for (let i = 0; i < 5; i++) {
                    transferParticles.push(new TransferParticle(
                        cidadeCenterX + random(-20, 20), cidadeCenterY + random(-20, 20),
                        campoCenterX + random(-10, 10), campoCenterY + random(-10, 10),
                        color(255, 255, 0), 'energia' // Amarelo para energia
                    ));
                }
            } else {
                eventoTemporario("Cidade não tem energia suficiente!");
            }
        }

        // Toca um som se a transferência foi bem-sucedida
        if (transferred) {
            transferSound.freq(440); // Frequência do som
            transferSound.amp(0.5, 0.05); // Aumenta o volume rapidamente
            transferSound.amp(0, 0.5); // Diminui o volume lentamente
        }

        // Checa conquista "Mãos Rápidas"
        if (transfersIn5Seconds >= 10) {
            desbloquearConquista("Mãos Rápidas");
        }
    }

    // Lógica para avançar na história com a tecla ESPAÇO
    if (telaAtual === "historia" && key === ' ' && podePressionarEspaco) {
        janelaHistoria++;
        // Verifica se todas as linhas da história foram exibidas
        if (janelaHistoria >= historiaText.length) {
            iniciarJogo(dificuldadeEscolhida); // Inicia o jogo após a história (que agora chama o tutorial)
        }
        podePressionarEspaco = false; // Impede múltiplas progressões se a tecla for mantida pressionada
    }

    // Lógica para reiniciar o jogo na tela de fim de jogo ou vitória
    if (telaAtual === "fim" || telaAtual === "vitoria") {
        if (key.toLowerCase() === 'r') {
            telaAtual = "menu"; // Volta para a tela de menu
            criarBotoesMenu(); // Recria os botões do menu para garantir que estejam visíveis e funcionais
            tutorialVistoPelaPrimeiraVez = false; // Permite que o tutorial seja visto novamente em uma nova jogada
        }
    }
}

/**
 * Função chamada uma vez quando uma tecla é liberada.
 * Usada para reativar a progressão da história com a tecla ESPAÇO.
 */
function keyReleased() {
    if (key === ' ') {
        podePressionarEspaco = true; // Permite pressionar ESPAÇO novamente
    }
}

// --- CLASSE PARA EFEITOS VISUAIS E EVENTOS ---

/**
 * Classe para partículas de transferência de recursos.
 */
class TransferParticle {
    constructor(startX, startY, targetX, targetY, color, type) {
        this.x = startX;
        this.y = startY;
        this.targetX = targetX;
        this.targetY = targetY;
        this.color = color;
        this.type = type; // 'comida', 'bens', 'agua', 'energia'
        this.size = random(8, 15);
        this.speed = random(5, 10);
        this.life = 255; // Para fade out
    }

    update() {
        let dx = this.targetX - this.x;
        let dy = this.targetY - this.y;
        let distToTarget = dist(this.x, this.y, this.targetX, this.targetY);

        if (distToTarget > this.speed) { // Move em direção ao alvo
            this.x += (dx / distToTarget) * this.speed;
            this.y += (dy / distToTarget) * this.speed;
        } else { // Se muito perto, "chega" ao alvo
            this.x = this.targetX;
            this.y = this.targetY;
            this.life = 0; // Marca para remoção
        }
        this.life -= 3; // Diminui a vida para fade out gradual
    }

    display() {
        push();
        noStroke();
        fill(this.color, this.life); // Aplica o fade out
        ellipse(this.x, this.y, this.size, this.size); // Desenha uma bolinha

        // Opcional: Desenhar ícones ou letras para o tipo de recurso
        // textSize(this.size * 0.8);
        // textAlign(CENTER, CENTER);
        // fill(0, this.life); // Cor preta para o texto
        // text(this.type[0].toUpperCase(), this.x, this.y);
        pop();
    }
}

/**
 * Classe para indicadores de aumento de produção (seta para cima).
 */
class ProdIndicator {
    constructor(x, y, color) {
        this.x = x;
        this.y = y;
        this.initialY = y;
        this.color = color;
        this.alpha = 255;
        this.size = 20;
        this.speedY = 1; // Velocidade de subida
        this.lifeSpan = 120; // Duração em frames
        this.frameCreated = frameCount;
    }

    update() {
        this.y -= this.speedY; // Sobe
        let elapsedFrames = frameCount - this.frameCreated;
        this.alpha = map(elapsedFrames, 0, this.lifeSpan, 255, 0); // Fade out
    }

    display() {
        push();
        fill(this.color, this.alpha);
        textSize(this.size);
        textAlign(CENTER, CENTER);
        text("⬆️", this.x, this.y); // Ícone de seta para cima
        pop();
    }
}

/**
 * Função auxiliar para adicionar um indicador de aumento de produção.
 */
function mostrarProducaoAumentada(x, y) {
    prodIncreaseIndicators.push(new ProdIndicator(x, y, color(0, 200, 0))); // Verde para aumento
}

// --- FUNÇÕES DE EVENTOS ALEATÓRIOS ---

/**
 * Lista de eventos possíveis. Cada evento tem um nome, um tipo (positivo/negativo)
 * e um efeito associado, além de uma duração em segundos.
 */
const listaEventos = [
    {
        nome: "Seca Prolongada",
        tipo: "seca",
        mensagem: "🔥 Uma seca prolongada atinge o Campo!",
        duracao: 15, // segundos
        efeito: () => { // Reduz produção de água e comida do campo
            campo.producaoAgua = max(0, campo.producaoAgua - 1);
            campo.producaoComida = max(0, campo.producaoComida - 1);
        },
        reverter: () => { // Restaura produção
            campo.producaoAgua += 1;
            campo.producaoComida += 1;
        }
    },
    {
        nome: "Inovação Urbana",
        tipo: "inovacao",
        mensagem: "💡 Nova tecnologia na Cidade!",
        duracao: 10,
        efeito: () => { // Aumenta produção de bens e energia da cidade
            cidade.producaoBens += 1;
            cidade.producaoEnergia += 0.5;
        },
        reverter: () => { // Reverte produção
            cidade.producaoBens = max(0, cidade.producaoBens - 1);
            cidade.producaoEnergia = max(0, cidade.producaoEnergia - 0.5);
        }
    },
    {
        nome: "Praga nas Plantações",
        tipo: "praga",
        mensagem: "🐛 Praga afeta as plantações do Campo!",
        duracao: 12,
        efeito: () => { // Reduz a produção de comida do campo
            campo.producaoComida = max(0, campo.producaoComida - 2);
        },
        reverter: () => { // Restaura a produção
            campo.producaoComida += 2;
        }
    },
    {
        nome: "Feriado Local",
        tipo: "feriado",
        mensagem: "🎉 Feriado celebra a produção de Bens!",
        duracao: 8,
        efeito: () => { // Aumenta a produção de bens da cidade
            cidade.producaoBens += 2;
        },
        reverter: () => { // Reverte a produção
            cidade.producaoBens = max(0, cidade.producaoBens - 2);
        }
    }
];

/**
 * Sorteia um evento aleatório com base em uma chance.
 */
function sortearEventoAleatorio() {
    if (eventoAtivo) return; // Não sorteia um novo evento se já houver um ativo

    if (random() < chanceEvento) { // Se a chance for atingida
        let eventoSorteado = random(listaEventos);
        eventoAtivo = eventoSorteado;
        eventoFimTempo = tempo + eventoSorteado.duracao;

        aplicarEfeitoEvento(eventoSorteado.tipo, true); // true para aplicar o efeito
        eventoTemporario(eventoSorteado.mensagem);
    }
}

/**
 * Aplica ou reverte os efeitos de um evento.
 * @param {string} tipoEvento - O tipo do evento (ex: "seca", "inovacao").
 * @param {boolean} aplicar - True para aplicar, false para reverter.
 */
function aplicarEfeitoEvento(tipoEvento, aplicar) {
    let evento = listaEventos.find(e => e.tipo === tipoEvento);
    if (!evento) return;

    if (aplicar) {
        evento.efeito();
    } else {
        evento.reverter();
    }

    // Checagem de conquistas relacionadas a eventos
    if (tipoEvento === "seca" && aplicar) {
        // A conquista "Sobrevivente da Seca" é checada na reversão do evento, se o campo não colapsou
    }
    if (tipoEvento === "inovacao" && aplicar && !cidade.colapsado && cidade.estabilidade === 0) {
        // "Impulsionador da Inovação" é checada quando o evento é ativado e a cidade está estável
        desbloquearConquista("Impulsionador da Inovação");
    }
}


// --- FUNÇÕES DE CONQUISTAS ---

/**
 * Inicializa o array de conquistas com seus dados e estado inicial.
 */
function inicializarConquistas() {
    conquistas = [
        // Progresso
        { id: "Primeiros Passos", nome: "Primeiros Passos", descricao: "Complete o tutorial do jogo.", unlocked: false },
        { id: "Novato Equilibrado", nome: "Novato Equilibrado", descricao: "Alcance a Fase 2.", unlocked: false },
        { id: "Construtor Experiente", nome: "Construtor Experiente", descricao: "Alcance a Fase 5.", unlocked: false },
        { id: "Mestre do Equilíbrio", nome: "Mestre do Equilíbrio", descricao: "Alcance a Fase 10.", unlocked: false },

        // Habilidade
        { id: "Mãos Rápidas", nome: "Mãos Rápidas", descricao: "Faça 10 transferências de recursos em 5 segundos.", unlocked: false },
        { id: "Sem Crises", nome: "Sem Crises", descricao: "Mantenha ambas as regiões sem instabilidade por 60 segundos.", unlocked: false },
        { id: "Recursos Abundantes", nome: "Recursos Abundantes", descricao: "Tenha mais de 50 unidades de cada recurso em ambas as regiões simultaneamente.", unlocked: false },
        { id: "Frugal", nome: "Frugal", descricao: "Avance de fase sem que nenhuma região tenha mais de 10 recursos por 30s antes do avanço.", unlocked: false },

        // Eventos Especiais
        { id: "Sobrevivente da Seca", nome: "Sobrevivente da Seca", descricao: "Não deixe o Campo colapsar durante um evento de 'Seca Prolongada'.", unlocked: false },
        { id: "Impulsionador da Inovação", nome: "Impulsionador da Inovação", descricao: "Beneficie-se da 'Inovação Urbana' sem ter a Cidade instável.", unlocked: false },

        // Dificuldade
        { id: "Vitória Descontraída", nome: "Vitória Descontraída", descricao: "Vença o jogo na dificuldade Fácil.", unlocked: false },
        { id: "Desafio Moderado", nome: "Desafio Moderado", descricao: "Vença o jogo na dificuldade Médio.", unlocked: false },
        { id: "A Lenda", nome: "A Lenda", descricao: "Vença o jogo na dificuldade Difícil.", unlocked: false },
    ];
}

/**
 * Desbloqueia uma conquista e exibe uma notificação.
 * @param {string} idConquista - O ID da conquista a ser desbloqueada.
 */
function desbloquearConquista(idConquista) {
    let conquista = conquistas.find(c => c.id === idConquista);
    if (conquista && !conquista.unlocked) {
        conquista.unlocked = true;
        conquistasDesbloqueadasNotificacoes.push({
            nome: conquista.nome,
            startTime: millis()
        });
        // Opcional: Adicionar pontos extras por conquista
        pontos += 50;
        console.log(`Conquista desbloqueada: ${conquista.nome}`);

        // Salvar estado das conquistas (ex: localStorage) para persistir entre sessões
        // localStorage.setItem("gameConquistas", JSON.stringify(conquistas));
    }
}

/**
 * Checa as condições para todas as conquistas a cada atualização de lógica.
 */
function checarConquistas() {
    // Conquista "Mãos Rápidas" - Já é checada no keyPressed

    // Conquista "Sem Crises"
    if (!campo.colapsado && campo.estabilidade === 0 && !cidade.colapsado && cidade.estabilidade === 0) {
        tempoSemInstabilidade++;
        if (tempoSemInstabilidade >= 60) {
            desbloquearConquista("Sem Crises");
        }
    } else {
        tempoSemInstabilidade = 0; // Reseta se houver instabilidade
    }

    // Conquista "Recursos Abundantes"
    if (campo.comida >= 50 && campo.bens >= 50 && campo.agua >= 50 && campo.energia >= 50 &&
        cidade.comida >= 50 && cidade.bens >= 50 && cidade.agua >= 50 && cidade.energia >= 50) {
        desbloquearConquista("Recursos Abundantes");
    }

    // Conquista "Frugal" - Lógica para acumular tempo
    // Verifica se os recursos estão "baixos" (<= 10) em ambas as regiões
    let campoRecursosBaixos = campo.comida <= 10 && campo.bens <= 10 && campo.agua <= 10 && campo.energia <= 10;
    let cidadeRecursosBaixos = cidade.comida <= 10 && cidade.bens <= 10 && cidade.agua <= 10 && cidade.energia <= 10;

    if (campoRecursosBaixos && cidadeRecursosBaixos) {
        tempoRecursosBaixosFrugal++; // Incrementa contador apenas se ambos estiverem baixos
    } else {
        tempoRecursosBaixosFrugal = 0; // Reseta se algum recurso ultrapassar o limite
    }
    // A checagem final e o desbloqueio da conquista "Frugal" acontecem no avanço de fase.

    // Conquista "Sobrevivente da Seca"
    // Esta será checada no final do evento "Seca Prolongada"
    if (eventoAtivo && eventoAtivo.tipo === "seca" && !eventoAtivo.aplicado && !campo.colapsado) {
        // Se o evento terminou e o campo não colapsou durante ele
        // Nota: 'aplicado' seria uma flag extra no objeto eventoAtivo para saber se o efeito foi aplicado,
        // ou podemos checar no aplicarEfeitoEvento quando reverter.
        // Por simplicidade, vou colocá-la na função aplicarEfeitoEvento na parte de reverter.
    }
}

/**
 * Exibe a tela de conquistas.
 */
function mostrarConquistas() {
    telaAtual = "conquistas";
    esconderBotoesMenu(true);

    botaoVoltar = createButton("🔙 Voltar");
    botaoVoltar.position(20, height - 50);
    botaoVoltar.mousePressed(() => {
        telaAtual = "menu";
        botaoVoltar.remove();
        esconderBotoesMenu(false);
    });
}

/**
 * Desenha a tela de conquistas.
 */
function desenharConquistas() {
    background(220, 240, 255); // Fundo azul claro para a tela de conquistas

    fill(30);
    textAlign(CENTER, TOP);
    textSize(32);
    textStyle(BOLD);
    text("🏆 Suas Conquistas 🏆", width / 2, 30);

    // Organiza as conquistas por categoria
    let conquistasPorCategoria = {
        "De Progresso": [],
        "De Habilidade": [],
        "De Eventos Especiais": [],
        "De Dificuldade": []
    };

    conquistas.forEach(c => {
        if (["Primeiros Passos", "Novato Equilibrado", "Construtor Experiente", "Mestre do Equilíbrio"].includes(c.id)) {
            conquistasPorCategoria["De Progresso"].push(c);
        } else if (["Mãos Rápidas", "Sem Crises", "Recursos Abundantes", "Frugal"].includes(c.id)) {
            conquistasPorCategoria["De Habilidade"].push(c);
        } else if (["Sobrevivente da Seca", "Impulsionador da Inovação"].includes(c.id)) {
            conquistasPorCategoria["De Eventos Especiais"].push(c);
        } else if (["Vitória Descontraída", "Desafio Moderado", "A Lenda"].includes(c.id)) {
            conquistasPorCategoria["De Dificuldade"].push(c);
        }
    });

    let startY = 80;
    let lineHeight = 25;
    let sectionSpacing = 30;

    textAlign(LEFT);
    textStyle(NORMAL);
    textSize(18);

    for (let categoria in conquistasPorCategoria) {
        fill(60);
        textStyle(BOLD);
        text(categoria, 50, startY); // Título da categoria
        startY += lineHeight;

        conquistasPorCategoria[categoria].forEach(conquista => {
            if (conquista.unlocked) {
                fill(50, 150, 50); // Verde para conquistado
                text("✅ " + conquista.nome, 70, startY);
                textSize(14);
                fill(80);
                text(conquista.descricao, 90, startY + 15);
                textSize(18); // Volta ao tamanho original
            } else {
                fill(150); // Cinza para não conquistado
                text("⬜ " + conquista.nome, 70, startY);
                textSize(14);
                fill(120);
                text(conquista.descricao, 90, startY + 15);
                textSize(18);
            }
            startY += lineHeight * 2; // Duas linhas por conquista (nome + descrição)
        });
        startY += sectionSpacing; // Espaço entre as categorias
    }

    // Garante que o botão voltar esteja visível
    if (botaoVoltar) botaoVoltar.show();
}


/**
 * Gerencia e desenha as notificações de conquistas desbloqueadas.
 */
function gerenciarNotificacoesConquistas() {
    // Remove notificações expiradas
    conquistasDesbloqueadasNotificacoes = conquistasDesbloqueadasNotificacoes.filter(
        n => millis() - n.startTime < TEMPO_NOTIFICACAO_CONQUISTA
    );

    // Desenha as notificações
    let notificationY = 30;
    for (let i = 0; i < conquistasDesbloqueadasNotificacoes.length; i++) {
        let notif = conquistasDesbloqueadasNotificacoes[i];
        let alpha = map(millis() - notif.startTime, 0, TEMPO_NOTIFICACAO_CONQUISTA, 255, 0);

        push();
        translate(width / 2, notificationY + i * 40); // Posiciona centralizado e empilhado
        fill(50, 150, 50, alpha); // Fundo verde para notificação de conquista
        rect(-150, -15, 300, 30, 10); // Caixa da notificação

        fill(255, alpha); // Texto branco
        textSize(16);
        textAlign(CENTER, CENTER);
        text(`🏆 Conquista: ${notif.nome} desbloqueada!`, 0, 0);
        pop();
    }
}